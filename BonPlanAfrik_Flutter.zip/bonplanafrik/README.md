# BonPlanAfrik — App Flutter

Application mobile de bons plans pour Libreville, Gabon (et Afrique francophone).
Projet scolaire — Collège de Paris Supérieur Gabon.

## Lancer le projet

```bash
flutter pub get
flutter run
```

## Structure

```
lib/
├── main.dart                  # Point d'entrée + navigation
├── theme/app_colors.dart      # Couleurs, styles (NE PAS MODIFIER les couleurs)
├── models/app_state.dart      # State management (Provider) : rôle, écran actif, favoris
├── data/mock_data.dart        # Données de démo (offres)
├── widgets/shared_widgets.dart# BottomNav (Client/Partenaire/Admin), OfferCard
└── screens/
    ├── auth/                  # Connexion, Inscription, Mot de passe oublié
    ├── client/                # Accueil, Recherche, Détail offre, Réservation,
    │                          # Favoris, Notifications, Profil
    ├── partner/                # Dashboard, Mes offres, Créer offre,
    │                          # Réservations, Profil commerce
    └── admin/                 # Dashboard, Validation offres, Utilisateurs, Catégories
```

## Couleurs (identiques à la maquette — ne pas changer)

| Usage       | Couleur     | Code        |
|-------------|-------------|-------------|
| Primaire (Client) | Orange | `#E8600A` |
| Secondaire (Partenaire) | Vert | `#1A7A4A` |
| Admin / texte foncé | Brun | `#1A1208` |
| Accent | Jaune | `#FFC947` |
| Fond | Beige clair | `#F6F3EE` |
| Erreur | Rouge | `#D4183D` |

## Ce qui a été ajouté par rapport à la maquette React, en s'appuyant sur le cahier des charges

- **Connexion rapide démo** sur l'écran d'authentification (3 boutons rôle) pour tester les 3 espaces facilement.
- **Module Admin complet** : Dashboard avec stats + graphique catégories, Validation des offres (workflow approuver/rejeter avec détail dépliable), Gestion des utilisateurs (recherche + filtre rôle + blocage/déblocage), Gestion des catégories (ajout/désactivation/suppression).
- **Module Partenaire complet** : Dashboard avec KPIs et réservations récentes, Mes offres (statut actif/en attente, stats vues/réservations), Créer une offre (formulaire complet : catégorie, prix, durée, photos), Réservations (confirmer/refuser).
- **Formatage des prix en FCFA** avec séparateur de milliers partout dans l'app.
- **State management centralisé** (Provider) pour gérer rôle actif, écran courant, favoris — remplace le useState local de chaque composant React par un seul `AppState` partagé, plus propre en Flutter.

## Prochaines étapes suggérées (voir cahier des charges)

- Intégration Firebase Auth (inscription/connexion réelles)
- Connexion Google Places API pour l'import automatique des établissements
- Backend réel (Firestore) pour remplacer `mock_data.dart`
- Carte interactive (Google Maps Flutter)
- Notifications push (Firebase Cloud Messaging)
- Paiement Airtel Money / Moov Money
