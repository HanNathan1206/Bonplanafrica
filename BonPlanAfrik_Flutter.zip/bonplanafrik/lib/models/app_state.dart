import 'package:flutter/material.dart';

enum UserRole { client, partner, admin }

enum ClientTab { home, search, favorites, profile }

enum PartnerTab { dashboard, offers, reservations, profile }

enum AdminTab { dashboard, validation, users, categories }

enum AppScreen {
  auth,
  // Client
  home, search, favorites, clientProfile, offerDetail, booking, notifications,
  // Partner
  partnerDashboard, partnerOffers, partnerCreate, partnerReservations, partnerProfile,
  // Admin
  adminDashboard, adminValidation, adminUsers, adminCategories,
}

class AppState extends ChangeNotifier {
  UserRole role = UserRole.client;
  AppScreen screen = AppScreen.auth;
  ClientTab clientTab = ClientTab.home;
  PartnerTab partnerTab = PartnerTab.dashboard;
  AdminTab adminTab = AdminTab.dashboard;
  String selectedOfferId = '1';
  Set<String> favorites = {'2'};

  void login(UserRole r) {
    role = r;
    if (r == UserRole.client) {
      screen = AppScreen.home;
      clientTab = ClientTab.home;
    } else if (r == UserRole.partner) {
      screen = AppScreen.partnerDashboard;
      partnerTab = PartnerTab.dashboard;
    } else {
      screen = AppScreen.adminDashboard;
      adminTab = AdminTab.dashboard;
    }
    notifyListeners();
  }

  void logout() {
    screen = AppScreen.auth;
    role = UserRole.client;
    notifyListeners();
  }

  void setScreen(AppScreen s) {
    screen = s;
    notifyListeners();
  }

  void setClientTab(ClientTab tab) {
    clientTab = tab;
    switch (tab) {
      case ClientTab.home: screen = AppScreen.home; break;
      case ClientTab.search: screen = AppScreen.search; break;
      case ClientTab.favorites: screen = AppScreen.favorites; break;
      case ClientTab.profile: screen = AppScreen.clientProfile; break;
    }
    notifyListeners();
  }

  void setPartnerTab(PartnerTab tab) {
    partnerTab = tab;
    switch (tab) {
      case PartnerTab.dashboard: screen = AppScreen.partnerDashboard; break;
      case PartnerTab.offers: screen = AppScreen.partnerOffers; break;
      case PartnerTab.reservations: screen = AppScreen.partnerReservations; break;
      case PartnerTab.profile: screen = AppScreen.partnerProfile; break;
    }
    notifyListeners();
  }

  void setAdminTab(AdminTab tab) {
    adminTab = tab;
    switch (tab) {
      case AdminTab.dashboard: screen = AppScreen.adminDashboard; break;
      case AdminTab.validation: screen = AppScreen.adminValidation; break;
      case AdminTab.users: screen = AppScreen.adminUsers; break;
      case AdminTab.categories: screen = AppScreen.adminCategories; break;
    }
    notifyListeners();
  }

  void selectOffer(String id) {
    selectedOfferId = id;
    screen = AppScreen.offerDetail;
    notifyListeners();
  }

  void toggleFavorite(String id) {
    if (favorites.contains(id)) {
      favorites.remove(id);
    } else {
      favorites.add(id);
    }
    notifyListeners();
  }

  bool isFavorite(String id) => favorites.contains(id);
}
