class OfferModel {
  final String id;
  final String title;
  final String business;
  final String category;
  final int originalPrice;
  final int discountedPrice;
  final int discount;
  final double rating;
  final int reviews;
  final String image;
  final String location;
  final String expiresAt;
  final String tag;
  final String description;

  const OfferModel({
    required this.id,
    required this.title,
    required this.business,
    required this.category,
    required this.originalPrice,
    required this.discountedPrice,
    required this.discount,
    required this.rating,
    required this.reviews,
    required this.image,
    required this.location,
    required this.expiresAt,
    required this.tag,
    required this.description,
  });

  int get savings => originalPrice - discountedPrice;
}

class MockData {
  static const List<OfferModel> offers = [
    OfferModel(
      id: '1',
      title: 'Menu Grillades + Boisson',
      business: 'Le Mandingue',
      category: 'restaurant',
      originalPrice: 12000,
      discountedPrice: 7500,
      discount: 38,
      rating: 4.8,
      reviews: 124,
      image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=400&h=300&fit=crop&auto=format',
      location: 'Libreville, Louis',
      expiresAt: 'Expire dans 2j',
      tag: '🔥 Top vente',
      description: 'Découvrez notre assortiment de grillades africaines : poulet yassa, poisson braisé, avec boisson au choix incluse.',
    ),
    OfferModel(
      id: '2',
      title: 'Chambre Standard — 2 nuits',
      business: 'Hôtel Le Cristal',
      category: 'hotel',
      originalPrice: 85000,
      discountedPrice: 55000,
      discount: 35,
      rating: 4.6,
      reviews: 89,
      image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=300&fit=crop&auto=format',
      location: 'Libreville, Centre',
      expiresAt: 'Expire dans 5j',
      tag: '🏨 Hébergement',
      description: 'Profitez de 2 nuits dans notre chambre standard avec petit-déjeuner inclus et accès à la piscine.',
    ),
    OfferModel(
      id: '3',
      title: 'Soin visage + Manucure',
      business: 'Beauty Afrik Spa',
      category: 'beaute',
      originalPrice: 25000,
      discountedPrice: 15000,
      discount: 40,
      rating: 4.9,
      reviews: 213,
      image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=400&h=300&fit=crop&auto=format',
      location: 'Libreville, Akanda',
      expiresAt: 'Expire dans 1j',
      tag: '⚡ Flash',
      description: 'Offre complète : soin visage hydratant 45 min + manucure gel couleur au choix.',
    ),
    OfferModel(
      id: '4',
      title: 'Coupe + Brushing',
      business: 'Salon Élégance',
      category: 'beaute',
      originalPrice: 8000,
      discountedPrice: 5000,
      discount: 38,
      rating: 4.7,
      reviews: 67,
      image: 'https://images.unsplash.com/photo-1560066984-138daaa0b1f1?w=400&h=300&fit=crop&auto=format',
      location: 'Libreville, Sotega',
      expiresAt: 'Expire dans 3j',
      tag: '✂️ Beauté',
      description: 'Coupe stylée + brushing professionnel avec nos coiffeuses expertes.',
    ),
    OfferModel(
      id: '5',
      title: 'Révision complète auto',
      business: 'Garage Mécaplus',
      category: 'services',
      originalPrice: 45000,
      discountedPrice: 28000,
      discount: 38,
      rating: 4.5,
      reviews: 41,
      image: 'https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?w=400&h=300&fit=crop&auto=format',
      location: 'Libreville, Nzeng-Ayong',
      expiresAt: 'Expire dans 7j',
      tag: '🔧 Services',
      description: 'Vidange + filtres + contrôle complet de votre véhicule par nos techniciens certifiés.',
    ),
    OfferModel(
      id: '6',
      title: 'Cours de cuisine africaine',
      business: 'Atelier Mama Akosua',
      category: 'loisirs',
      originalPrice: 15000,
      discountedPrice: 9000,
      discount: 40,
      rating: 5.0,
      reviews: 33,
      image: 'https://images.unsplash.com/photo-1507048331197-7d4ac70811cf?w=400&h=300&fit=crop&auto=format',
      location: 'Libreville, Owendo',
      expiresAt: 'Expire dans 4j',
      tag: '🍳 Loisirs',
      description: 'Apprenez à cuisiner 3 plats traditionnels : ndolé, poulet moambé, beignets de fève.',
    ),
  ];

  static const List<Map<String, String>> categories = [
    {'id': 'all', 'label': 'Tout', 'emoji': '🌍'},
    {'id': 'restaurant', 'label': 'Restos', 'emoji': '🍽️'},
    {'id': 'hotel', 'label': 'Hôtels', 'emoji': '🏨'},
    {'id': 'beaute', 'label': 'Beauté', 'emoji': '💅'},
    {'id': 'services', 'label': 'Services', 'emoji': '🔧'},
    {'id': 'loisirs', 'label': 'Loisirs', 'emoji': '🎯'},
  ];
}
