import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../models/app_state.dart';
import '../data/mock_data.dart';

// ─── BOTTOM NAV CLIENT ───────────────────────────────────────────────────────

class ClientBottomNav extends StatelessWidget {
  final ClientTab activeTab;
  final ValueChanged<ClientTab> onTabChange;
  final int favoriteCount;

  const ClientBottomNav({
    super.key,
    required this.activeTab,
    required this.onTabChange,
    required this.favoriteCount,
  });

  @override
  Widget build(BuildContext context) {
    final tabs = [
      _NavItem(tab: ClientTab.home, icon: Icons.home_rounded, label: 'Accueil'),
      _NavItem(tab: ClientTab.search, icon: Icons.search_rounded, label: 'Recherche'),
      _NavItem(tab: ClientTab.favorites, icon: Icons.favorite_rounded, label: 'Favoris'),
      _NavItem(tab: ClientTab.profile, icon: Icons.person_rounded, label: 'Profil'),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Color(0x141A1208), blurRadius: 20, offset: Offset(0, -4))],
      ),
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: tabs.map((t) {
          final isActive = activeTab == t.tab;
          return GestureDetector(
            onTap: () => onTabChange(t.tab),
            child: Stack(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 40,
                        height: 32,
                        decoration: BoxDecoration(
                          color: isActive ? const Color(0xFFFFF3E0) : Colors.transparent,
                          borderRadius: BorderRadius.circular(AppRadius.lg),
                        ),
                        child: Icon(t.icon, size: 22, color: isActive ? AppColors.primary : AppColors.placeholder),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        t.label,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                          color: isActive ? AppColors.primary : AppColors.placeholder,
                        ),
                      ),
                    ],
                  ),
                ),
                if (t.tab == ClientTab.favorites && favoriteCount > 0)
                  Positioned(
                    top: 0,
                    right: 12,
                    child: Container(
                      width: 16,
                      height: 16,
                      decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
                      child: Center(
                        child: Text('$favoriteCount', style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _NavItem {
  final dynamic tab;
  final IconData icon;
  final String label;
  const _NavItem({required this.tab, required this.icon, required this.label});
}

// ─── BOTTOM NAV PARTENAIRE ───────────────────────────────────────────────────

class PartnerBottomNav extends StatelessWidget {
  final PartnerTab activeTab;
  final ValueChanged<PartnerTab> onTabChange;

  const PartnerBottomNav({super.key, required this.activeTab, required this.onTabChange});

  @override
  Widget build(BuildContext context) {
    final tabs = [
      (PartnerTab.dashboard, Icons.dashboard_rounded, 'Dashboard'),
      (PartnerTab.offers, Icons.description_rounded, 'Offres'),
      (PartnerTab.reservations, Icons.calendar_month_rounded, 'Réservations'),
      (PartnerTab.profile, Icons.store_rounded, 'Commerce'),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Color(0x141A1208), blurRadius: 20, offset: Offset(0, -4))],
      ),
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: tabs.map((t) {
          final isActive = activeTab == t.$1;
          return GestureDetector(
            onTap: () => onTabChange(t.$1),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 32,
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFFE8F5E9) : Colors.transparent,
                    borderRadius: BorderRadius.circular(AppRadius.lg),
                  ),
                  child: Icon(t.$2, size: 22, color: isActive ? AppColors.secondary : AppColors.placeholder),
                ),
                const SizedBox(height: 2),
                Text(
                  t.$3,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                    color: isActive ? AppColors.secondary : AppColors.placeholder,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ─── BOTTOM NAV ADMIN ────────────────────────────────────────────────────────

class AdminBottomNav extends StatelessWidget {
  final AdminTab activeTab;
  final ValueChanged<AdminTab> onTabChange;

  const AdminBottomNav({super.key, required this.activeTab, required this.onTabChange});

  @override
  Widget build(BuildContext context) {
    final tabs = [
      (AdminTab.dashboard, Icons.bar_chart_rounded, 'Dashboard'),
      (AdminTab.validation, Icons.verified_rounded, 'Validation'),
      (AdminTab.users, Icons.group_rounded, 'Utilisateurs'),
      (AdminTab.categories, Icons.category_rounded, 'Catégories'),
    ];

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: Color(0x141A1208), blurRadius: 20, offset: Offset(0, -4))],
      ),
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: tabs.map((t) {
          final isActive = activeTab == t.$1;
          return GestureDetector(
            onTap: () => onTabChange(t.$1),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 40,
                  height: 32,
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFFEEEEEE) : Colors.transparent,
                    borderRadius: BorderRadius.circular(AppRadius.lg),
                  ),
                  child: Icon(t.$2, size: 22, color: isActive ? AppColors.dark : AppColors.placeholder),
                ),
                const SizedBox(height: 2),
                Text(
                  t.$3,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
                    color: isActive ? AppColors.dark : AppColors.placeholder,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ─── OFFER CARD ──────────────────────────────────────────────────────────────

class OfferCard extends StatelessWidget {
  final OfferModel offer;
  final bool isFavorite;
  final VoidCallback onTap;
  final VoidCallback onToggleFavorite;

  const OfferCard({
    super.key,
    required this.offer,
    required this.isFavorite,
    required this.onTap,
    required this.onToggleFavorite,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.xxl),
          boxShadow: const [BoxShadow(color: Color(0x141A1208), blurRadius: 12, offset: Offset(0, 2))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(AppRadius.xxl),
                    topRight: Radius.circular(AppRadius.xxl),
                  ),
                  child: Image.network(
                    offer.image,
                    height: 176,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      height: 176,
                      color: AppColors.muted,
                      child: const Icon(Icons.image_rounded, size: 48, color: AppColors.placeholder),
                    ),
                  ),
                ),
                // Tag
                Positioned(
                  top: 12,
                  left: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(offer.tag, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                  ),
                ),
                // Discount badge
                Positioned(
                  top: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(99)),
                    child: Text('-${offer.discount}%', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                  ),
                ),
                // Favorite button
                Positioned(
                  bottom: 12,
                  right: 12,
                  child: GestureDetector(
                    onTap: onToggleFavorite,
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: Color(0x261A1208), blurRadius: 8, offset: Offset(0, 2))]),
                      child: Icon(
                        isFavorite ? Icons.favorite : Icons.favorite_border,
                        size: 16,
                        color: isFavorite ? AppColors.primary : AppColors.placeholder,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            // Info
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(offer.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.dark)),
                  const SizedBox(height: 2),
                  Text(offer.business, style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      const Icon(Icons.star_rounded, size: 13, color: AppColors.accent),
                      const SizedBox(width: 2),
                      Text('${offer.rating}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.dark)),
                      Text(' (${offer.reviews})', style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
                      const SizedBox(width: 8),
                      const Icon(Icons.location_on_rounded, size: 12, color: AppColors.mutedFg),
                      const SizedBox(width: 2),
                      Expanded(child: Text(offer.location, style: const TextStyle(fontSize: 11, color: AppColors.mutedFg), overflow: TextOverflow.ellipsis)),
                      const Icon(Icons.access_time_rounded, size: 12, color: AppColors.primary),
                      const SizedBox(width: 2),
                      Text(offer.expiresAt, style: const TextStyle(fontSize: 11, color: AppColors.primary, fontWeight: FontWeight.w600)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Text(
                        '${offer.discountedPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]} ')} F',
                        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppColors.primary),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${offer.originalPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]} ')} F',
                        style: const TextStyle(fontSize: 13, color: AppColors.placeholder, decoration: TextDecoration.lineThrough),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
