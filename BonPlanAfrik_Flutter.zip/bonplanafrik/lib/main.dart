import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'theme/app_colors.dart';
import 'models/app_state.dart';
import 'screens/auth/auth_screen.dart';
import 'screens/client/home_screen.dart';
import 'screens/client/search_screen.dart';
import 'screens/client/offer_detail_screen.dart';
import 'screens/client/client_screens.dart';
import 'screens/partner/partner_screens.dart';
import 'screens/admin/admin_screens.dart';
import 'widgets/shared_widgets.dart';

void main() {
  runApp(const BonPlanAfrikApp());
}

class BonPlanAfrikApp extends StatelessWidget {
  const BonPlanAfrikApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState(),
      child: MaterialApp(
        title: 'BonPlanAfrik',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          fontFamily: 'Poppins',
          scaffoldBackgroundColor: AppColors.background,
          colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
          useMaterial3: true,
        ),
        home: const RootScreen(),
      ),
    );
  }
}

class RootScreen extends StatelessWidget {
  const RootScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return _buildScreen(state);
  }

  Widget _buildScreen(AppState state) {
    switch (state.screen) {
      case AppScreen.auth:
        return const AuthScreen();

      // ─── CLIENT ───────────────────────────────────────────────────────────
      case AppScreen.home:
        return _withClientNav(state, const HomeScreen());
      case AppScreen.search:
        return _withClientNav(state, const SearchScreen());
      case AppScreen.favorites:
        return _withClientNav(state, const FavoritesScreen());
      case AppScreen.clientProfile:
        return _withClientNav(state, const ClientProfileScreen());
      case AppScreen.offerDetail:
        return const OfferDetailScreen();
      case AppScreen.booking:
        return const BookingScreen();
      case AppScreen.notifications:
        return const NotificationsScreen();

      // ─── PARTNER ──────────────────────────────────────────────────────────
      case AppScreen.partnerDashboard:
        return _withPartnerNav(state, const PartnerDashboardScreen());
      case AppScreen.partnerOffers:
        return _withPartnerNav(state, const PartnerOffersScreen());
      case AppScreen.partnerReservations:
        return _withPartnerNav(state, const PartnerReservationsScreen());
      case AppScreen.partnerProfile:
        return _withPartnerNav(state, const PartnerProfileScreen());
      case AppScreen.partnerCreate:
        return const CreateOfferScreen();

      // ─── ADMIN ────────────────────────────────────────────────────────────
      case AppScreen.adminDashboard:
        return _withAdminNav(state, const AdminDashboardScreen());
      case AppScreen.adminValidation:
        return _withAdminNav(state, const AdminValidationScreen());
      case AppScreen.adminUsers:
        return _withAdminNav(state, const AdminUsersScreen());
      case AppScreen.adminCategories:
        return _withAdminNav(state, const AdminCategoriesScreen());
    }
  }

  Widget _withClientNav(AppState state, Widget screen) {
    return Scaffold(
      body: screen,
      bottomNavigationBar: ClientBottomNav(
        activeTab: state.clientTab,
        onTabChange: state.setClientTab,
        favoriteCount: state.favorites.length,
      ),
    );
  }

  Widget _withPartnerNav(AppState state, Widget screen) {
    return Scaffold(
      body: screen,
      bottomNavigationBar: PartnerBottomNav(
        activeTab: state.partnerTab,
        onTabChange: state.setPartnerTab,
      ),
    );
  }

  Widget _withAdminNav(AppState state, Widget screen) {
    return Scaffold(
      body: screen,
      bottomNavigationBar: AdminBottomNav(
        activeTab: state.adminTab,
        onTabChange: state.setAdminTab,
      ),
    );
  }
}
