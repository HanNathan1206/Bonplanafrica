import 'package:flutter/material.dart';

class AppColors {
  // Couleurs principales — NE PAS MODIFIER
  static const Color primary = Color(0xFFE8600A);       // Orange BonPlanAfrik
  static const Color secondary = Color(0xFF1A7A4A);     // Vert Partenaire
  static const Color dark = Color(0xFF1A1208);          // Brun foncé Admin/texte
  static const Color accent = Color(0xFFFFC947);        // Jaune accent
  static const Color destructive = Color(0xFFD4183D);   // Rouge erreur

  // Fond & surfaces
  static const Color background = Color(0xFFF6F3EE);
  static const Color card = Color(0xFFFFFFFF);
  static const Color inputBg = Color(0xFFEFEBE3);
  static const Color muted = Color(0xFFEDE9E1);
  static const Color mutedFg = Color(0xFF7A6E5F);
  static const Color border = Color(0x1F1A1208);
  static const Color placeholder = Color(0xFFC5BDB0);

  // Dégradés
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFFE8600A), Color(0xFFFFC947)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient secondaryGradient = LinearGradient(
    colors: [Color(0xFF1A7A4A), Color(0xFF27AE60)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient adminGradient = LinearGradient(
    colors: [Color(0xFF1A1208), Color(0xFF3D2B1A)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient bgGradient = LinearGradient(
    colors: [Color(0xFF1A1208), Color(0xFF3D2B1A), Color(0xFF8B3A0F)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0.0, 0.4, 1.0],
  );

  // Couleurs catégories
  static const Color catRestaurant = Color(0xFFE8600A);
  static const Color catHotel = Color(0xFF1A7A4A);
  static const Color catBeaute = Color(0xFFFFC947);
  static const Color catServices = Color(0xFF8E44AD);
  static const Color catLoisirs = Color(0xFFC5BDB0);
}

class AppRadius {
  static const double sm = 10.0;
  static const double md = 14.0;
  static const double lg = 18.0;
  static const double xl = 24.0;
  static const double xxl = 32.0;
}

class AppTextStyles {
  static const TextStyle h1 = TextStyle(
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w800,
    fontSize: 24,
    color: AppColors.dark,
  );
  static const TextStyle h2 = TextStyle(
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w700,
    fontSize: 20,
    color: AppColors.dark,
  );
  static const TextStyle h3 = TextStyle(
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w700,
    fontSize: 16,
    color: AppColors.dark,
  );
  static const TextStyle body = TextStyle(
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w400,
    fontSize: 14,
    color: AppColors.dark,
  );
  static const TextStyle caption = TextStyle(
    fontFamily: 'Poppins',
    fontWeight: FontWeight.w400,
    fontSize: 12,
    color: AppColors.mutedFg,
  );
}
