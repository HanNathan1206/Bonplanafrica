import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/app_state.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

typedef AuthView = String;

class _AuthScreenState extends State<AuthScreen> {
  String view = 'login'; // login | register | forgot
  bool showPassword = false;
  final emailCtrl = TextEditingController();
  final passwordCtrl = TextEditingController();
  final nameCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  UserRole selectedRole = UserRole.client;
  bool forgotSent = false;

  @override
  Widget build(BuildContext context) {
    if (view == 'forgot') return _buildForgot();
    if (view == 'register') return _buildRegister();
    return _buildLogin();
  }

  Widget _buildLogin() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          // Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(24, 72, 24, 32),
            decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('🌍', style: TextStyle(fontSize: 36)),
                    const SizedBox(width: 10),
                    const Text('BonPlanAfrik', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 26)),
                  ],
                ),
                const SizedBox(height: 12),
                const Text('Bons plans à Libreville et\nen Afrique francophone 🇬🇦', style: TextStyle(color: Colors.white70, fontSize: 14)),
              ],
            ),
          ),
          // Form
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Connexion', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 22, color: AppColors.dark)),
                  const SizedBox(height: 6),
                  const Text('Accédez à vos bons plans', style: TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                  const SizedBox(height: 24),
                  _buildField('Email', emailCtrl, Icons.mail_rounded, type: TextInputType.emailAddress),
                  const SizedBox(height: 14),
                  _buildPasswordField(),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: () => setState(() => view = 'forgot'),
                      child: const Text('Mot de passe oublié ?', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600, fontSize: 13)),
                    ),
                  ),
                  const SizedBox(height: 24),
                  // Quick login buttons
                  const Text('Connexion rapide (démo)', style: TextStyle(color: AppColors.mutedFg, fontSize: 12)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _quickLoginBtn('🛍️ Client', UserRole.client, AppColors.primary),
                      const SizedBox(width: 8),
                      _quickLoginBtn('🏪 Partenaire', UserRole.partner, AppColors.secondary),
                      const SizedBox(width: 8),
                      _quickLoginBtn('⚙️ Admin', UserRole.admin, AppColors.dark),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _gradientButton('Se connecter', () {
                    context.read<AppState>().login(UserRole.client);
                  }),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Pas encore de compte ? ", style: TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                      GestureDetector(
                        onTap: () => setState(() => view = 'register'),
                        child: const Text("S'inscrire", style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 13)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRegister() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(24, 72, 24, 28),
            decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => setState(() => view = 'login'),
                  child: const Row(
                    children: [
                      Icon(Icons.arrow_back_ios_rounded, color: Colors.white70, size: 18),
                      Text('Retour', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Créer un compte', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 26)),
                const Text('Rejoignez BonPlanAfrik dès maintenant', style: TextStyle(color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Role selector
                  Row(
                    children: [
                      Expanded(child: _roleBtn('Client', UserRole.client)),
                      const SizedBox(width: 12),
                      Expanded(child: _roleBtn('Partenaire', UserRole.partner)),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _buildField('Nom complet', nameCtrl, Icons.person_rounded),
                  const SizedBox(height: 14),
                  _buildField('Email', emailCtrl, Icons.mail_rounded, type: TextInputType.emailAddress),
                  const SizedBox(height: 14),
                  _buildField('Téléphone (+241)', phoneCtrl, Icons.phone_rounded, type: TextInputType.phone),
                  const SizedBox(height: 14),
                  _buildPasswordField(),
                  if (selectedRole == UserRole.partner) ...[
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE8F5E9),
                        borderRadius: BorderRadius.circular(AppRadius.lg),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.info_rounded, color: AppColors.secondary, size: 18),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Votre compte sera examiné par notre équipe avant activation.',
                              style: TextStyle(color: AppColors.secondary, fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 24),
                  _gradientButton("Créer mon compte", () => context.read<AppState>().login(selectedRole)),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('Déjà inscrit ? ', style: TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                      GestureDetector(
                        onTap: () => setState(() => view = 'login'),
                        child: const Text('Se connecter', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 13)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildForgot() {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(24, 72, 24, 28),
            decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => setState(() { view = 'login'; forgotSent = false; }),
                  child: const Row(
                    children: [
                      Icon(Icons.arrow_back_ios_rounded, color: Colors.white70, size: 18),
                      Text('Retour', style: TextStyle(color: Colors.white70, fontSize: 13)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Mot de passe oublié', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 26)),
                const Text("Entrez votre email pour recevoir un lien", style: TextStyle(color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: forgotSent
                  ? Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: const BoxDecoration(color: Color(0xFFE8F5E9), shape: BoxShape.circle),
                          child: const Icon(Icons.mail_rounded, size: 36, color: AppColors.secondary),
                        ),
                        const SizedBox(height: 20),
                        const Text('Email envoyé !', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 20, color: AppColors.dark)),
                        const SizedBox(height: 8),
                        const Text('Vérifiez votre boite mail pour réinitialiser votre mot de passe.',
                            textAlign: TextAlign.center, style: TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                        const SizedBox(height: 32),
                        _gradientButton('Retour à la connexion', () => setState(() { view = 'login'; forgotSent = false; })),
                      ],
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildField('Email', emailCtrl, Icons.mail_rounded, type: TextInputType.emailAddress),
                        const SizedBox(height: 24),
                        _gradientButton('Envoyer le lien', () => setState(() => forgotSent = true)),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildField(String label, TextEditingController ctrl, IconData icon, {TextInputType type = TextInputType.text}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.dark)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.xl)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(
            children: [
              Icon(icon, size: 18, color: AppColors.mutedFg),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: ctrl,
                  keyboardType: type,
                  style: const TextStyle(fontSize: 14, color: AppColors.dark),
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: label,
                    hintStyle: const TextStyle(color: AppColors.placeholder, fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPasswordField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Mot de passe', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.dark)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.xl)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(
            children: [
              const Icon(Icons.lock_rounded, size: 18, color: AppColors.mutedFg),
              const SizedBox(width: 12),
              Expanded(
                child: TextField(
                  controller: passwordCtrl,
                  obscureText: !showPassword,
                  style: const TextStyle(fontSize: 14, color: AppColors.dark),
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    hintText: '••••••••',
                    hintStyle: TextStyle(color: AppColors.placeholder, fontSize: 14),
                  ),
                ),
              ),
              GestureDetector(
                onTap: () => setState(() => showPassword = !showPassword),
                child: Icon(showPassword ? Icons.visibility_rounded : Icons.visibility_off_rounded, size: 18, color: AppColors.mutedFg),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _quickLoginBtn(String label, UserRole role, Color color) {
    return Expanded(
      child: GestureDetector(
        onTap: () => context.read<AppState>().login(role),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Text(label, textAlign: TextAlign.center, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: color)),
        ),
      ),
    );
  }

  Widget _roleBtn(String label, UserRole role) {
    final isActive = selectedRole == role;
    return GestureDetector(
      onTap: () => setState(() => selectedRole = role),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          gradient: isActive ? AppColors.primaryGradient : null,
          color: isActive ? null : AppColors.inputBg,
          borderRadius: BorderRadius.circular(AppRadius.xl),
        ),
        child: Text(label, textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w700, color: isActive ? Colors.white : AppColors.mutedFg)),
      ),
    );
  }

  Widget _gradientButton(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl)),
        child: Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
      ),
    );
  }
}
