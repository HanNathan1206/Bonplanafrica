import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/app_state.dart';
import '../../data/mock_data.dart';
import '../../widgets/shared_widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String activeCategory = 'all';

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final filtered = activeCategory == 'all'
        ? MockData.offers
        : MockData.offers.where((o) => o.category == activeCategory).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          // Header gradient
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 16),
            decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Bonjour 👋', style: TextStyle(color: Colors.white70, fontSize: 12)),
                          const Text('Jean Mba', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 20)),
                          const SizedBox(height: 4),
                          const Row(
                            children: [
                              Icon(Icons.location_on_rounded, size: 12, color: Colors.white70),
                              SizedBox(width: 2),
                              Text('Libreville, Gabon', style: TextStyle(color: Colors.white70, fontSize: 11)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    GestureDetector(
                      onTap: () => state.setScreen(AppScreen.notifications),
                      child: Stack(
                        children: [
                          Container(
                            width: 40, height: 40,
                            decoration: BoxDecoration(
                              color: Colors.white24,
                              borderRadius: BorderRadius.circular(AppRadius.lg),
                            ),
                            child: const Icon(Icons.notifications_rounded, color: Colors.white, size: 18),
                          ),
                          Positioned(
                            top: 6, right: 6,
                            child: Container(
                              width: 8, height: 8,
                              decoration: BoxDecoration(color: Colors.red, shape: BoxShape.circle,
                                  border: Border.all(color: Colors.white, width: 1)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Search bar
                GestureDetector(
                  onTap: () => state.setClientTab(ClientTab.search),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(AppRadius.xl),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.search_rounded, color: Colors.white60, size: 16),
                        SizedBox(width: 10),
                        Text("Rechercher une offre...", style: TextStyle(color: Colors.white60, fontSize: 13)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Content
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                // Flash deals banner
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: AppColors.secondaryGradient,
                      borderRadius: BorderRadius.circular(AppRadius.xl),
                    ),
                    child: const Row(
                      children: [
                        _GreenIconBox(),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Offres Flash du jour', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                              Text('3 offres expirent dans moins de 24h !', style: TextStyle(color: Colors.white70, fontSize: 11)),
                            ],
                          ),
                        ),
                        Icon(Icons.chevron_right_rounded, color: Colors.white70),
                      ],
                    ),
                  ),
                ),
                // Categories
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: const Text('Catégories', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.dark)),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 80,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    scrollDirection: Axis.horizontal,
                    itemCount: MockData.categories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 10),
                    itemBuilder: (context, i) {
                      final cat = MockData.categories[i];
                      final isActive = activeCategory == cat['id'];
                      return GestureDetector(
                        onTap: () => setState(() => activeCategory = cat['id']!),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: isActive ? AppColors.primary : Colors.white,
                            borderRadius: BorderRadius.circular(AppRadius.xl),
                            boxShadow: [
                              BoxShadow(
                                color: isActive ? AppColors.primary.withOpacity(0.3) : const Color(0x141A1208),
                                blurRadius: isActive ? 12 : 4,
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(cat['emoji']!, style: const TextStyle(fontSize: 20)),
                              const SizedBox(height: 4),
                              Text(cat['label']!, style: TextStyle(
                                fontSize: 11, fontWeight: FontWeight.w600,
                                color: isActive ? Colors.white : AppColors.mutedFg,
                              )),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                // Offers
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Offres du jour', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.dark)),
                      Text('Voir tout', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600, fontSize: 12)),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                ...filtered.map((offer) => Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
                  child: OfferCard(
                    offer: offer,
                    isFavorite: state.isFavorite(offer.id),
                    onTap: () => state.selectOffer(offer.id),
                    onToggleFavorite: () => state.toggleFavorite(offer.id),
                  ),
                )),
                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _GreenIconBox extends StatelessWidget {
  const _GreenIconBox();
  @override
  Widget build(BuildContext context) => Container(
    width: 40, height: 40,
    decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(AppRadius.lg)),
    child: const Icon(Icons.bolt_rounded, color: Colors.white, size: 20),
  );
}
