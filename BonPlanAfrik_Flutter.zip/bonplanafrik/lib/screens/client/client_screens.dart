import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/app_state.dart';
import '../../data/mock_data.dart';
import '../../widgets/shared_widgets.dart';

// ─── BOOKING SCREEN ──────────────────────────────────────────────────────────

class BookingScreen extends StatefulWidget {
  const BookingScreen({super.key});
  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  int persons = 2;
  String selectedDate = '20 Juin 2026';
  String selectedTime = '12:00';
  bool confirmed = false;

  final dates = ['19 Juin', '20 Juin', '21 Juin', '22 Juin', '23 Juin'];
  final times = ['11:00', '12:00', '13:00', '14:00', '19:00', '20:00'];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final offer = MockData.offers.firstWhere((o) => o.id == state.selectedOfferId, orElse: () => MockData.offers[0]);

    if (confirmed) {
      return Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100, height: 100,
                decoration: const BoxDecoration(gradient: AppColors.secondaryGradient, shape: BoxShape.circle),
                child: const Icon(Icons.check_rounded, color: Colors.white, size: 50),
              ),
              const SizedBox(height: 24),
              const Text('Réservation confirmée !', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.dark)),
              const SizedBox(height: 8),
              const Text('Vous recevrez une confirmation\npar SMS et email',
                  textAlign: TextAlign.center, style: TextStyle(color: AppColors.mutedFg, fontSize: 13)),
              const SizedBox(height: 32),
              GestureDetector(
                onTap: () { state.setClientTab(ClientTab.home); },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                  decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl)),
                  child: const Text('Retour à l\'accueil', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => state.setScreen(AppScreen.offerDetail),
                  child: const Row(children: [
                    Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
                    Text('Retour', style: TextStyle(color: Colors.white, fontSize: 13)),
                  ]),
                ),
                const SizedBox(height: 16),
                const Text('Réservation', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 22)),
                Text(offer.title, style: const TextStyle(color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                // Offer summary
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 10)]),
                  child: Row(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(AppRadius.lg),
                        child: Image.network(offer.image, width: 70, height: 70, fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(width: 70, height: 70, color: AppColors.muted)),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(offer.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.dark)),
                            Text(offer.business, style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
                            const SizedBox(height: 4),
                            Text('${offer.discountedPrice} F', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary, fontSize: 16)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                // Date
                _sectionTitle('Choisissez une date'),
                const SizedBox(height: 10),
                SizedBox(
                  height: 56,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: dates.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, i) {
                      final isActive = selectedDate == '${dates[i]} 2026';
                      return GestureDetector(
                        onTap: () => setState(() => selectedDate = '${dates[i]} 2026'),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: BoxDecoration(
                            color: isActive ? AppColors.primary : Colors.white,
                            borderRadius: BorderRadius.circular(AppRadius.lg),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(dates[i].split(' ')[0], style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14,
                                  color: isActive ? Colors.white : AppColors.dark)),
                              Text(dates[i].split(' ')[1], style: TextStyle(fontSize: 10,
                                  color: isActive ? Colors.white70 : AppColors.mutedFg)),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 20),
                // Time
                _sectionTitle('Heure'),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8, runSpacing: 8,
                  children: times.map((t) {
                    final isActive = selectedTime == t;
                    return GestureDetector(
                      onTap: () => setState(() => selectedTime = t),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                        decoration: BoxDecoration(
                          color: isActive ? AppColors.primary : Colors.white,
                          borderRadius: BorderRadius.circular(AppRadius.lg),
                        ),
                        child: Text(t, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13,
                            color: isActive ? Colors.white : AppColors.dark)),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),
                // Persons
                _sectionTitle('Nombre de personnes'),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Personnes', style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.dark)),
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () { if (persons > 1) setState(() => persons--); },
                            child: Container(width: 32, height: 32,
                                decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                child: const Icon(Icons.remove_rounded, size: 16, color: AppColors.dark)),
                          ),
                          Padding(padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Text('$persons', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppColors.dark))),
                          GestureDetector(
                            onTap: () => setState(() => persons++),
                            child: Container(width: 32, height: 32,
                                decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                child: const Icon(Icons.add_rounded, size: 16, color: Colors.white)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 30),
                GestureDetector(
                  onTap: () => setState(() => confirmed = true),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl)),
                    child: Text('Confirmer la réservation • ${offer.discountedPrice} F',
                        textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String title) => Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.dark));
}

// ─── FAVORITES SCREEN ────────────────────────────────────────────────────────

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final favOffers = MockData.offers.where((o) => state.isFavorite(o.id)).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Mes Favoris', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.dark)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(99)),
                  child: Text('${favOffers.length} offre${favOffers.length > 1 ? 's' : ''}',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
                ),
              ],
            ),
          ),
          Expanded(
            child: favOffers.isEmpty
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('💝', style: TextStyle(fontSize: 56)),
                        SizedBox(height: 16),
                        Text('Aucun favori', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18, color: AppColors.dark)),
                        Text('Ajoutez des offres à vos favoris\nen cliquant sur ♥', textAlign: TextAlign.center,
                            style: TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                      ],
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
                    itemCount: favOffers.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 16),
                    itemBuilder: (context, i) => OfferCard(
                      offer: favOffers[i],
                      isFavorite: true,
                      onTap: () => state.selectOffer(favOffers[i].id),
                      onToggleFavorite: () => state.toggleFavorite(favOffers[i].id),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

// ─── NOTIFICATIONS SCREEN ────────────────────────────────────────────────────

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final notifs = [
      {'icon': '🔥', 'title': 'Offre flash : -50% Spa Akanda', 'subtitle': 'Expire dans 3h seulement !', 'time': 'Il y a 5 min', 'unread': true, 'color': 0xFFE8600A},
      {'icon': '✅', 'title': 'Réservation confirmée', 'subtitle': 'Le Mandingue — 20 Juin 12h00', 'time': 'Il y a 1h', 'unread': true, 'color': 0xFF1A7A4A},
      {'icon': '⭐', 'title': 'Nouvelle offre : Hôtel Le Cristal', 'subtitle': '-35% sur chambres ce weekend', 'time': 'Il y a 3h', 'unread': false, 'color': 0xFFFFC947},
      {'icon': '🎁', 'title': 'Code promo : GABON10', 'subtitle': '10% de réduction sur votre prochaine réservation', 'time': 'Hier', 'unread': false, 'color': 0xFF8E44AD},
      {'icon': '📍', 'title': 'Nouvelle offre près de vous', 'subtitle': 'Salon Élégance — Coupe + Brushing 5 000 F', 'time': 'Hier', 'unread': false, 'color': 0xFFE8600A},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => state.setScreen(AppScreen.home),
                      child: const Icon(Icons.arrow_back_ios_new_rounded, size: 20, color: AppColors.dark),
                    ),
                    const SizedBox(width: 12),
                    const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20, color: AppColors.dark)),
                  ],
                ),
                const Text('Tout lire', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600, fontSize: 13)),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(vertical: 8),
              itemCount: notifs.length,
              separatorBuilder: (_, __) => const Divider(height: 1, color: AppColors.muted),
              itemBuilder: (context, i) {
                final n = notifs[i];
                return Container(
                  color: (n['unread'] as bool) ? const Color(0xFFFFF8F5) : Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: Color(n['color'] as int).withOpacity(0.12),
                          borderRadius: BorderRadius.circular(AppRadius.lg),
                        ),
                        child: Center(child: Text(n['icon'] as String, style: const TextStyle(fontSize: 20))),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(n['title'] as String, style: TextStyle(
                              fontWeight: (n['unread'] as bool) ? FontWeight.w700 : FontWeight.w500,
                              fontSize: 13, color: AppColors.dark,
                            )),
                            const SizedBox(height: 2),
                            Text(n['subtitle'] as String, style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(n['time'] as String, style: const TextStyle(fontSize: 10, color: AppColors.mutedFg)),
                          if (n['unread'] as bool) ...[
                            const SizedBox(height: 6),
                            Container(width: 8, height: 8, decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle)),
                          ],
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── PROFILE SCREEN ──────────────────────────────────────────────────────────

class ClientProfileScreen extends StatelessWidget {
  const ClientProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 30),
            decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
            child: Column(
              children: [
                Container(
                  width: 80, height: 80,
                  decoration: const BoxDecoration(color: Colors.white24, shape: BoxShape.circle),
                  child: const Center(child: Text('JM', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 26))),
                ),
                const SizedBox(height: 12),
                const Text('Jean Mba', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20)),
                const Text('jean.mba@email.com', style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _statPill('12', 'Réservations'),
                    const SizedBox(width: 12),
                    _statPill('5', 'Avis donnés'),
                    const SizedBox(width: 12),
                    _statPill('8', 'Favoris'),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12),
              children: [
                _menuSection('Mon compte', [
                  _menuItem(Icons.person_rounded, 'Mes informations', () {}),
                  _menuItem(Icons.calendar_month_rounded, 'Mes réservations', () {}),
                  _menuItem(Icons.favorite_rounded, 'Mes favoris', () => state.setClientTab(ClientTab.favorites)),
                  _menuItem(Icons.star_rounded, 'Mes avis', () {}),
                ]),
                const SizedBox(height: 8),
                _menuSection('Paiement', [
                  _menuItem(Icons.account_balance_wallet_rounded, 'Airtel Money / Moov Money', () {}),
                  _menuItem(Icons.card_giftcard_rounded, 'Mes codes promo', () {}),
                ]),
                const SizedBox(height: 8),
                _menuSection('Paramètres', [
                  _menuItem(Icons.notifications_rounded, 'Notifications', () {}),
                  _menuItem(Icons.language_rounded, 'Langue : Français', () {}),
                  _menuItem(Icons.help_rounded, 'Aide & Support', () {}),
                ]),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GestureDetector(
                    onTap: () => state.logout(),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(color: const Color(0xFFFFF0F0), borderRadius: BorderRadius.circular(AppRadius.xl)),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.logout_rounded, color: AppColors.destructive, size: 18),
                          SizedBox(width: 8),
                          Text('Se déconnecter', style: TextStyle(color: AppColors.destructive, fontWeight: FontWeight.w700, fontSize: 15)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 90),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _statPill(String value, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(AppRadius.lg)),
    child: Column(children: [
      Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)),
    ]),
  );

  static Widget _menuSection(String title, List<Widget> items) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 8, top: 4),
          child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.mutedFg)),
        ),
        Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
              boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 8)]),
          child: Column(children: items),
        ),
      ],
    ),
  );

  static Widget _menuItem(IconData icon, String label, VoidCallback onTap) => GestureDetector(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(children: [
        Container(width: 36, height: 36,
            decoration: BoxDecoration(color: AppColors.muted, borderRadius: BorderRadius.circular(AppRadius.md)),
            child: Icon(icon, size: 18, color: AppColors.mutedFg)),
        const SizedBox(width: 12),
        Expanded(child: Text(label, style: const TextStyle(fontSize: 14, color: AppColors.dark, fontWeight: FontWeight.w500))),
        const Icon(Icons.chevron_right_rounded, size: 18, color: AppColors.placeholder),
      ]),
    ),
  );
}
