import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/app_state.dart';
import '../../data/mock_data.dart';
import '../../widgets/shared_widgets.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final queryCtrl = TextEditingController();
  String selectedCity = 'Libreville';
  String selectedCat = 'Tout';
  int maxPrice = 100000;
  bool showFilters = false;
  String query = '';

  static const cities = ['Libreville', 'Port-Gentil', 'Franceville', 'Oyem'];
  static const cats = ['Tout', 'Restaurants', 'Hôtels', 'Beauté', 'Services', 'Loisirs'];

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final filtered = MockData.offers.where((o) {
      final q = query.toLowerCase();
      final matchQ = q.isEmpty || o.title.toLowerCase().contains(q) || o.business.toLowerCase().contains(q);
      final matchCat = selectedCat == 'Tout' || o.category == _catToId(selectedCat);
      final matchPrice = o.discountedPrice <= maxPrice;
      return matchQ && matchCat && matchPrice;
    }).toList();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Recherche', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 20, color: AppColors.dark)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.xl)),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                        child: Row(
                          children: [
                            const Icon(Icons.search_rounded, size: 16, color: AppColors.mutedFg),
                            const SizedBox(width: 10),
                            Expanded(
                              child: TextField(
                                controller: queryCtrl,
                                onChanged: (v) => setState(() => query = v),
                                style: const TextStyle(fontSize: 13, color: AppColors.dark),
                                decoration: const InputDecoration(
                                  border: InputBorder.none, isDense: true,
                                  hintText: 'Restaurant, hôtel, offre...',
                                  hintStyle: TextStyle(color: AppColors.placeholder, fontSize: 13),
                                ),
                              ),
                            ),
                            if (query.isNotEmpty)
                              GestureDetector(
                                onTap: () { queryCtrl.clear(); setState(() => query = ''); },
                                child: const Icon(Icons.close_rounded, size: 14, color: AppColors.mutedFg),
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: () => setState(() => showFilters = !showFilters),
                      child: Container(
                        width: 44, height: 44,
                        decoration: BoxDecoration(
                          color: showFilters ? AppColors.primary : AppColors.inputBg,
                          borderRadius: BorderRadius.circular(AppRadius.xl),
                        ),
                        child: Icon(Icons.tune_rounded, size: 18, color: showFilters ? Colors.white : AppColors.mutedFg),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // City pills
                SizedBox(
                  height: 32,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: cities.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, i) {
                      final isActive = selectedCity == cities[i];
                      return GestureDetector(
                        onTap: () => setState(() => selectedCity = cities[i]),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: isActive ? AppColors.primary : AppColors.inputBg,
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text(cities[i], style: TextStyle(
                            fontSize: 12, fontWeight: FontWeight.w600,
                            color: isActive ? Colors.white : AppColors.mutedFg,
                          )),
                        ),
                      );
                    },
                  ),
                ),
                // Filters
                if (showFilters) ...[
                  const SizedBox(height: 12),
                  const Text('Catégorie', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: AppColors.dark)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: cats.map((c) {
                      final isActive = selectedCat == c;
                      return GestureDetector(
                        onTap: () => setState(() => selectedCat = c),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: isActive ? AppColors.primary : AppColors.inputBg,
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text(c, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                              color: isActive ? Colors.white : AppColors.mutedFg)),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Prix max', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: AppColors.dark)),
                      Text('${(maxPrice / 1000).round()} 000 F', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 13)),
                    ],
                  ),
                  Slider(
                    value: maxPrice.toDouble(),
                    min: 5000, max: 100000, divisions: 19,
                    activeColor: AppColors.primary,
                    inactiveColor: AppColors.muted,
                    onChanged: (v) => setState(() => maxPrice = v.round()),
                  ),
                ],
              ],
            ),
          ),
          // Results
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 90),
              children: [
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text('${filtered.length} résultat${filtered.length > 1 ? 's' : ''}',
                      style: const TextStyle(color: AppColors.mutedFg, fontSize: 13, fontWeight: FontWeight.w600)),
                ),
                ...filtered.map((offer) => Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: OfferCard(
                    offer: offer,
                    isFavorite: state.isFavorite(offer.id),
                    onTap: () => state.selectOffer(offer.id),
                    onToggleFavorite: () => state.toggleFavorite(offer.id),
                  ),
                )),
                if (filtered.isEmpty)
                  const Center(
                    child: Padding(
                      padding: EdgeInsets.only(top: 60),
                      child: Column(children: [
                        Text('🔍', style: TextStyle(fontSize: 48)),
                        SizedBox(height: 12),
                        Text('Aucune offre trouvée', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.dark)),
                        Text('Essayez d\'autres filtres', style: TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                      ]),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _catToId(String cat) {
    return cat.toLowerCase()
        .replaceAll('restaurants', 'restaurant')
        .replaceAll('hôtels', 'hotel')
        .replaceAll('beauté', 'beaute')
        .replaceAll('services', 'services')
        .replaceAll('loisirs', 'loisirs');
  }
}
