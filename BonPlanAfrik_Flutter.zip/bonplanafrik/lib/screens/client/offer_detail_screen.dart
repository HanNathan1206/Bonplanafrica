import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/app_state.dart';
import '../../data/mock_data.dart';

class OfferDetailScreen extends StatelessWidget {
  const OfferDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final offer = MockData.offers.firstWhere((o) => o.id == state.selectedOfferId, orElse: () => MockData.offers[0]);
    final isFav = state.isFavorite(offer.id);

    final reviews = [
      {'name': 'Amina K.', 'rating': 5, 'text': 'Super expérience, je recommande vivement !', 'initials': 'AK', 'date': 'Il y a 3j'},
      {'name': 'Pierre M.', 'rating': 4, 'text': 'Très bon rapport qualité/prix, service impeccable.', 'initials': 'PM', 'date': 'Il y a 1 sem'},
      {'name': 'Fatou D.', 'rating': 5, 'text': 'Incroyable ! J\'y retourne bientôt.', 'initials': 'FD', 'date': 'Il y a 2 sem'},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          Column(
            children: [
              // Hero image
              Stack(
                children: [
                  SizedBox(
                    height: 260,
                    width: double.infinity,
                    child: Image.network(offer.image, fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: AppColors.muted)),
                  ),
                  Container(height: 260, decoration: const BoxDecoration(
                    gradient: LinearGradient(colors: [Colors.transparent, Colors.black54],
                        begin: Alignment.topCenter, end: Alignment.bottomCenter, stops: [0.4, 1.0]),
                  )),
                  SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            onTap: () => state.setScreen(state.clientTab == ClientTab.home ? AppScreen.home : AppScreen.search),
                            child: _circleBtn(const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.dark)),
                          ),
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () => state.toggleFavorite(offer.id),
                                child: _circleBtn(Icon(isFav ? Icons.favorite : Icons.favorite_border,
                                    size: 18, color: isFav ? AppColors.primary : AppColors.dark)),
                              ),
                              const SizedBox(width: 8),
                              _circleBtn(const Icon(Icons.share_rounded, size: 18, color: AppColors.dark)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 16, left: 20,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(99)),
                      child: Text('-${offer.discount}% AUJOURD\'HUI',
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13)),
                    ),
                  ),
                ],
              ),
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.only(bottom: 110),
                  children: [
                    // Main info
                    Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(offer.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppColors.dark)),
                                    const SizedBox(height: 4),
                                    Text(offer.business, style: const TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    _formatPrice(offer.discountedPrice),
                                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.primary),
                                  ),
                                  Text(
                                    _formatPrice(offer.originalPrice),
                                    style: const TextStyle(fontSize: 14, color: AppColors.placeholder, decoration: TextDecoration.lineThrough),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          const SizedBox(height: 14),
                          // Badges
                          Row(
                            children: [
                              _infoBadge(Icons.star_rounded, '${offer.rating} (${offer.reviews})', AppColors.accent),
                              const SizedBox(width: 8),
                              _infoBadge(Icons.location_on_rounded, offer.location, AppColors.mutedFg),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: [
                              _infoBadge(Icons.access_time_rounded, offer.expiresAt, AppColors.primary),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                decoration: BoxDecoration(color: const Color(0xFFFFF3E0), borderRadius: BorderRadius.circular(99)),
                                child: Text('Économisez ${_formatPrice(offer.savings)} !',
                                    style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 11)),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Description
                    Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('À propos de l\'offre', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.dark)),
                          const SizedBox(height: 10),
                          Text(offer.description, style: const TextStyle(color: AppColors.mutedFg, fontSize: 13, height: 1.5)),
                          const SizedBox(height: 16),
                          // Guarantees
                          ...['Réservation 100% sécurisée', 'Satisfait ou remboursé', 'Support WhatsApp disponible'].map(
                            (g) => Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Row(children: [
                                const Icon(Icons.check_circle_rounded, size: 16, color: AppColors.secondary),
                                const SizedBox(width: 8),
                                Text(g, style: const TextStyle(fontSize: 13, color: AppColors.dark)),
                              ]),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    // Reviews
                    Container(
                      color: Colors.white,
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Avis clients', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.dark)),
                              Text('${offer.reviews} avis', style: const TextStyle(color: AppColors.mutedFg, fontSize: 12)),
                            ],
                          ),
                          const SizedBox(height: 14),
                          ...reviews.map((r) => _reviewItem(r)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          // Bottom booking bar
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [BoxShadow(color: Color(0x1A000000), blurRadius: 20, offset: Offset(0, -4))],
              ),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(_formatPrice(offer.discountedPrice),
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 20, color: AppColors.primary)),
                      Text('au lieu de ${_formatPrice(offer.originalPrice)}',
                          style: const TextStyle(fontSize: 11, color: AppColors.placeholder, decoration: TextDecoration.lineThrough)),
                    ],
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => state.setScreen(AppScreen.booking),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl)),
                        child: const Text('Réserver maintenant', textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _circleBtn(Widget child) => Container(
    width: 40, height: 40,
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), shape: BoxShape.circle,
        boxShadow: const [BoxShadow(color: Color(0x261A1208), blurRadius: 8, offset: Offset(0, 2))]),
    child: Center(child: child),
  );

  Widget _infoBadge(IconData icon, String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(99)),
    child: Row(children: [
      Icon(icon, size: 13, color: color),
      const SizedBox(width: 4),
      Text(text, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color)),
    ]),
  );

  Widget _reviewItem(Map<String, dynamic> r) => Padding(
    padding: const EdgeInsets.only(bottom: 14),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(gradient: AppColors.primaryGradient, shape: BoxShape.circle),
          child: Center(child: Text(r['initials'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12))),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(r['name'], style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.dark)),
                  Text(r['date'], style: const TextStyle(fontSize: 11, color: AppColors.mutedFg)),
                ],
              ),
              Row(children: List.generate(5, (i) => Icon(Icons.star_rounded, size: 12,
                  color: i < (r['rating'] as int) ? AppColors.accent : AppColors.placeholder))),
              const SizedBox(height: 2),
              Text(r['text'], style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
            ],
          ),
        ),
      ],
    ),
  );

  String _formatPrice(int price) {
    final s = price.toString();
    final result = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) result.write(' ');
      result.write(s[i]);
    }
    return '${result.toString()} F';
  }
}
