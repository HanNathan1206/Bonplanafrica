import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/app_state.dart';

// ─── ADMIN DASHBOARD ─────────────────────────────────────────────────────────

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    final kpis = [
      {'label': 'Utilisateurs', 'value': '1 298', 'icon': '👥', 'color': AppColors.primary, 'change': '+23 ce mois', 'tab': AdminTab.users},
      {'label': 'Offres actives', 'value': '91', 'icon': '📋', 'color': AppColors.secondary, 'change': '+12 cette sem.', 'tab': null},
      {'label': 'Réservations', 'value': '428', 'icon': '📅', 'color': const Color(0xFF8E44AD), 'change': '+67 ce mois', 'tab': null},
      {'label': 'En attente', 'value': '7', 'icon': '⏳', 'color': AppColors.destructive, 'change': 'À valider', 'tab': AdminTab.validation},
    ];

    final catData = [
      {'name': 'Restaurant', 'value': 38, 'color': AppColors.primary},
      {'name': 'Hôtels', 'value': 22, 'color': AppColors.secondary},
      {'name': 'Beauté', 'value': 19, 'color': AppColors.accent},
      {'name': 'Services', 'value': 14, 'color': const Color(0xFF8E44AD)},
      {'name': 'Autres', 'value': 7, 'color': AppColors.placeholder},
    ];

    final actions = [
      {'label': 'Valider les offres en attente', 'sub': '7 offres à examiner', 'icon': '📋', 'color': AppColors.primary, 'tab': AdminTab.validation},
      {'label': 'Gérer les utilisateurs', 'sub': '1 298 comptes actifs', 'icon': '👥', 'color': AppColors.secondary, 'tab': AdminTab.users},
      {'label': 'Gérer les catégories', 'sub': '5 catégories actives', 'icon': '🏷️', 'color': const Color(0xFF8E44AD), 'tab': AdminTab.categories},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            decoration: const BoxDecoration(gradient: AppColors.adminGradient),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Administration', style: TextStyle(color: Colors.white60, fontSize: 12)),
                const Text('BonPlanAfrik', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 22)),
                const Text('Tableau de bord · 19 Juin 2026', style: TextStyle(color: Colors.white60, fontSize: 12)),
                const SizedBox(height: 16),
                GridView.count(
                  crossAxisCount: 2, childAspectRatio: 1.7,
                  shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 12, mainAxisSpacing: 12,
                  children: kpis.map((k) => GestureDetector(
                    onTap: () { if (k['tab'] != null) state.setAdminTab(k['tab'] as AdminTab); },
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(AppRadius.xl)),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(k['icon'] as String, style: const TextStyle(fontSize: 22)),
                          const SizedBox(height: 4),
                          Text(k['value'] as String, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                          Container(
                            margin: const EdgeInsets.only(top: 2),
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(color: (k['color'] as Color).withOpacity(0.18), borderRadius: BorderRadius.circular(99)),
                            child: Text(k['change'] as String, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: k['color'] as Color)),
                          ),
                          Text(k['label'] as String, style: const TextStyle(color: Colors.white60, fontSize: 10)),
                        ],
                      ),
                    ),
                  )).toList(),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
              children: [
                // Categories pie
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 10)]),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Offres par catégorie', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.dark)),
                      const SizedBox(height: 12),
                      ...catData.map((c) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            Container(width: 10, height: 10, decoration: BoxDecoration(color: c['color'] as Color, shape: BoxShape.circle)),
                            const SizedBox(width: 8),
                            Expanded(child: Text(c['name'] as String, style: const TextStyle(fontSize: 12, color: AppColors.mutedFg))),
                            Text('${c['value']}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.dark)),
                          ],
                        ),
                      )),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text('Actions rapides', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.dark)),
                const SizedBox(height: 10),
                ...actions.map((a) => GestureDetector(
                  onTap: () => state.setAdminTab(a['tab'] as AdminTab),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                        boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 8)]),
                    child: Row(
                      children: [
                        Container(width: 40, height: 40,
                            decoration: BoxDecoration(color: (a['color'] as Color).withOpacity(0.1), borderRadius: BorderRadius.circular(AppRadius.lg)),
                            child: Center(child: Text(a['icon'] as String, style: const TextStyle(fontSize: 20)))),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(a['label'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.dark)),
                              Text(a['sub'] as String, style: const TextStyle(fontSize: 11, color: AppColors.mutedFg)),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_right_rounded, size: 18, color: AppColors.placeholder),
                      ],
                    ),
                  ),
                )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─── ADMIN VALIDATION ────────────────────────────────────────────────────────

class AdminValidationScreen extends StatefulWidget {
  const AdminValidationScreen({super.key});
  @override
  State<AdminValidationScreen> createState() => _AdminValidationScreenState();
}

class _AdminValidationScreenState extends State<AdminValidationScreen> {
  final Map<String, String> decisions = {};
  String? expanded;

  final pendingOffers = const [
    {'id': 'P001', 'title': 'Buffet Africain Complet', 'business': 'Resto Chez Mama', 'category': 'Restaurant', 'city': 'Libreville', 'original': 18000, 'discounted': 11000, 'discount': 39, 'submittedAt': "Aujourd'hui, 09h32", 'description': 'Buffet varié avec 15 plats traditionnels, boissons incluses.'},
    {'id': 'P002', 'title': 'Massage Relax 60 min', 'business': 'Oasis Spa & Bien-être', 'category': 'Beauté', 'city': 'Port-Gentil', 'original': 30000, 'discounted': 18000, 'discount': 40, 'submittedAt': "Aujourd'hui, 11h15", 'description': 'Massage relaxant 60 minutes avec huiles essentielles naturelles.'},
    {'id': 'P003', 'title': 'Cours de Tennis — 5 séances', 'business': 'Tennis Club Gabon', 'category': 'Loisirs', 'city': 'Libreville', 'original': 40000, 'discounted': 25000, 'discount': 38, 'submittedAt': 'Hier, 16h48', 'description': "5 séances d'initiation ou perfectionnement avec coach certifié."},
    {'id': 'P004', 'title': 'Location voiture 3 jours', 'business': 'AutoRent Gabon', 'category': 'Services', 'city': 'Libreville', 'original': 90000, 'discounted': 65000, 'discount': 28, 'submittedAt': 'Hier, 14h20', 'description': 'Location véhicule climatisé 3 jours, kilométrage illimité, assurance incluse.'},
    {'id': 'P005', 'title': 'Coiffure + Extensions', 'business': 'Salon Natural Hair', 'category': 'Beauté', 'city': 'Franceville', 'original': 35000, 'discounted': 22000, 'discount': 37, 'submittedAt': 'Il y a 2j', 'description': "Pose d'extensions naturelles + coiffure au choix."},
  ];

  @override
  Widget build(BuildContext context) {
    final pending = pendingOffers.where((o) => !decisions.containsKey(o['id'])).toList();
    final approvedCount = decisions.values.where((d) => d == 'approved').length;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Validation des offres', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.dark)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    _statusPill('${pending.length} en attente', AppColors.primary, const Color(0xFFFFF3E0)),
                    const SizedBox(width: 10),
                    _statusPill('$approvedCount approuvées', AppColors.secondary, const Color(0xFFE8F5E9)),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: pending.isEmpty
                ? const Center(
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('✅', style: TextStyle(fontSize: 56)),
                      SizedBox(height: 12),
                      Text('Tout est validé !', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.dark)),
                    ]),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
                    itemCount: pending.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, i) {
                      final o = pending[i];
                      final isExpanded = expanded == o['id'];
                      return Container(
                        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                            boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 10)]),
                        child: Column(
                          children: [
                            GestureDetector(
                              onTap: () => setState(() => expanded = isExpanded ? null : o['id'] as String),
                              child: Padding(
                                padding: const EdgeInsets.all(16),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Row(children: [
                                            Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                                decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(4)),
                                                child: Text('#${o['id']}', style: const TextStyle(fontSize: 10, color: AppColors.mutedFg))),
                                            const SizedBox(width: 6),
                                            Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                                decoration: BoxDecoration(color: const Color(0xFFFFF3E0), borderRadius: BorderRadius.circular(99)),
                                                child: Text(o['category'] as String, style: const TextStyle(fontSize: 10, color: AppColors.primary, fontWeight: FontWeight.w600))),
                                          ]),
                                          const SizedBox(height: 6),
                                          Text(o['title'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.dark)),
                                          Text(o['business'] as String, style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
                                          const SizedBox(height: 4),
                                          Row(children: [
                                            const Icon(Icons.location_on_rounded, size: 11, color: AppColors.mutedFg),
                                            const SizedBox(width: 2),
                                            Text(o['city'] as String, style: const TextStyle(fontSize: 11, color: AppColors.mutedFg)),
                                            const SizedBox(width: 10),
                                            Text(o['submittedAt'] as String, style: const TextStyle(fontSize: 11, color: AppColors.placeholder)),
                                          ]),
                                        ],
                                      ),
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text('${o['discounted']} F', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: AppColors.primary)),
                                        Text('${o['original']} F', style: const TextStyle(fontSize: 11, color: AppColors.placeholder, decoration: TextDecoration.lineThrough)),
                                        Container(margin: const EdgeInsets.only(top: 2), padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                            decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(99)),
                                            child: Text('-${o['discount']}%', style: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w700))),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            if (isExpanded)
                              Container(
                                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                                decoration: const BoxDecoration(border: Border(top: BorderSide(color: AppColors.muted))),
                                child: Column(
                                  children: [
                                    const SizedBox(height: 12),
                                    Text(o['description'] as String, style: const TextStyle(fontSize: 12, color: AppColors.mutedFg, height: 1.4)),
                                    const SizedBox(height: 12),
                                    Row(children: [
                                      Expanded(
                                        child: GestureDetector(
                                          onTap: () => setState(() { decisions[o['id'] as String] = 'rejected'; expanded = null; }),
                                          child: Container(padding: const EdgeInsets.symmetric(vertical: 12),
                                              decoration: BoxDecoration(color: const Color(0xFFFFF0F0), borderRadius: BorderRadius.circular(AppRadius.lg)),
                                              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                Icon(Icons.close_rounded, size: 16, color: AppColors.destructive),
                                                SizedBox(width: 6),
                                                Text('Rejeter', style: TextStyle(color: AppColors.destructive, fontWeight: FontWeight.w700, fontSize: 13)),
                                              ])),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: GestureDetector(
                                          onTap: () => setState(() { decisions[o['id'] as String] = 'approved'; expanded = null; }),
                                          child: Container(padding: const EdgeInsets.symmetric(vertical: 12),
                                              decoration: BoxDecoration(gradient: AppColors.secondaryGradient, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                              child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                                                Icon(Icons.check_rounded, size: 16, color: Colors.white),
                                                SizedBox(width: 6),
                                                Text('Approuver', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                                              ])),
                                        ),
                                      ),
                                    ]),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _statusPill(String label, Color color, Color bg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(99)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 6),
      Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
    ]),
  );
}

// ─── ADMIN USERS ─────────────────────────────────────────────────────────────

class AdminUsersScreen extends StatefulWidget {
  const AdminUsersScreen({super.key});
  @override
  State<AdminUsersScreen> createState() => _AdminUsersScreenState();
}

class _AdminUsersScreenState extends State<AdminUsersScreen> {
  String query = '';
  String filterRole = 'all';
  final Map<String, String> statuses = {};

  final users = const [
    {'id': 'U001', 'name': 'Amina Koumba', 'email': 'amina.k@gmail.com', 'role': 'client', 'city': 'Libreville', 'joinDate': 'Jan 2026', 'reservations': 8, 'status': 'active'},
    {'id': 'U002', 'name': 'Pierre Mboumba', 'email': 'p.mboumba@gmail.com', 'role': 'client', 'city': 'Port-Gentil', 'joinDate': 'Fév 2026', 'reservations': 3, 'status': 'active'},
    {'id': 'U003', 'name': 'Le Mandingue', 'email': 'contact@lemandingue.ga', 'role': 'partner', 'city': 'Libreville', 'joinDate': 'Mar 2026', 'reservations': 52, 'status': 'active'},
    {'id': 'U004', 'name': 'Fatou Diallo', 'email': 'fatou.d@gmail.com', 'role': 'client', 'city': 'Brazzaville', 'joinDate': 'Mar 2026', 'reservations': 12, 'status': 'blocked'},
    {'id': 'U005', 'name': 'Beauty Afrik Spa', 'email': 'info@beautyafrik.ga', 'role': 'partner', 'city': 'Libreville', 'joinDate': 'Avr 2026', 'reservations': 34, 'status': 'active'},
    {'id': 'U006', 'name': 'Jean-Claude Ondo', 'email': 'jc.ondo@gmail.com', 'role': 'client', 'city': 'Franceville', 'joinDate': 'Avr 2026', 'reservations': 1, 'status': 'active'},
    {'id': 'U007', 'name': 'Hôtel Le Cristal', 'email': 'reservation@lecristal.ga', 'role': 'partner', 'city': 'Libreville', 'joinDate': 'Jan 2026', 'reservations': 89, 'status': 'active'},
  ];

  @override
  Widget build(BuildContext context) {
    final filtered = users.where((u) {
      final q = query.toLowerCase();
      final matchQ = q.isEmpty || (u['name'] as String).toLowerCase().contains(q) || (u['email'] as String).toLowerCase().contains(q);
      final matchRole = filterRole == 'all' || u['role'] == filterRole;
      return matchQ && matchRole;
    }).toList();

    final blockedCount = users.where((u) => (statuses[u['id']] ?? u['status']) == 'blocked').length;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Utilisateurs', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.dark)),
                Text('${users.length} comptes · $blockedCount bloqués', style: const TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                  decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.xl)),
                  child: Row(children: [
                    const Icon(Icons.search_rounded, size: 16, color: AppColors.mutedFg),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        onChanged: (v) => setState(() => query = v),
                        style: const TextStyle(fontSize: 13, color: AppColors.dark),
                        decoration: const InputDecoration(border: InputBorder.none, isDense: true, hintText: 'Nom, email...',
                            hintStyle: TextStyle(color: AppColors.placeholder, fontSize: 13)),
                      ),
                    ),
                  ]),
                ),
                const SizedBox(height: 10),
                Row(
                  children: ['all', 'client', 'partner'].map((r) {
                    final isActive = filterRole == r;
                    return Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GestureDetector(
                        onTap: () => setState(() => filterRole = r),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                          decoration: BoxDecoration(
                            color: isActive ? AppColors.dark : AppColors.inputBg,
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text(r == 'all' ? 'Tous' : r == 'client' ? 'Clients' : 'Partenaires',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: isActive ? Colors.white : AppColors.mutedFg)),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
              itemCount: filtered.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, i) {
                final u = filtered[i];
                final status = statuses[u['id']] ?? u['status'] as String;
                final isPartner = u['role'] == 'partner';
                final isActive = status == 'active';
                return Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 8)]),
                  child: Row(
                    children: [
                      Container(width: 40, height: 40,
                          decoration: BoxDecoration(color: isPartner ? const Color(0xFFE8F5E9) : const Color(0xFFFFF3E0), borderRadius: BorderRadius.circular(AppRadius.lg)),
                          child: Icon(isPartner ? Icons.store_rounded : Icons.person_rounded, size: 18,
                              color: isPartner ? AppColors.secondary : AppColors.primary)),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(u['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.dark)),
                            Text(u['email'] as String, style: const TextStyle(fontSize: 11, color: AppColors.mutedFg)),
                            Text('${u['city']} · ${u['reservations']} résas · ${u['joinDate']}', style: const TextStyle(fontSize: 10, color: AppColors.placeholder)),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => statuses[u['id'] as String] = isActive ? 'blocked' : 'active'),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: isActive ? const Color(0xFFE8F5E9) : const Color(0xFFFFF0F0),
                            borderRadius: BorderRadius.circular(99),
                          ),
                          child: Text(isActive ? 'Actif' : 'Bloqué',
                              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: isActive ? AppColors.secondary : AppColors.destructive)),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── ADMIN CATEGORIES ────────────────────────────────────────────────────────

class AdminCategoriesScreen extends StatefulWidget {
  const AdminCategoriesScreen({super.key});
  @override
  State<AdminCategoriesScreen> createState() => _AdminCategoriesScreenState();
}

class _AdminCategoriesScreenState extends State<AdminCategoriesScreen> {
  List<Map<String, dynamic>> cats = [
    {'id': 1, 'name': 'Restaurant', 'emoji': '🍽️', 'count': 38, 'active': true},
    {'id': 2, 'name': 'Hôtel', 'emoji': '🏨', 'count': 22, 'active': true},
    {'id': 3, 'name': 'Beauté', 'emoji': '💅', 'count': 19, 'active': true},
    {'id': 4, 'name': 'Services', 'emoji': '🔧', 'count': 14, 'active': true},
    {'id': 5, 'name': 'Loisirs', 'emoji': '🎯', 'count': 7, 'active': true},
    {'id': 6, 'name': 'Sport', 'emoji': '⚽', 'count': 3, 'active': false},
  ];
  bool showAdd = false;
  final nameCtrl = TextEditingController();
  final emojiCtrl = TextEditingController(text: '🏷️');

  @override
  Widget build(BuildContext context) {
    final activeCount = cats.where((c) => c['active'] == true).length;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Catégories', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.dark)),
                    Text('$activeCount actives · ${cats.length} total', style: const TextStyle(color: AppColors.mutedFg, fontSize: 13)),
                  ],
                ),
                GestureDetector(
                  onTap: () => setState(() => showAdd = !showAdd),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(gradient: AppColors.adminGradient, borderRadius: BorderRadius.circular(AppRadius.lg)),
                    child: const Row(children: [
                      Icon(Icons.add_rounded, color: Colors.white, size: 16),
                      SizedBox(width: 4),
                      Text('Ajouter', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
                    ]),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
              children: [
                if (showAdd)
                  Container(
                    margin: const EdgeInsets.only(bottom: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                        boxShadow: const [BoxShadow(color: Color(0x1A000000), blurRadius: 12)]),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Nouvelle catégorie', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.dark)),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Container(width: 48, height: 48,
                                decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                child: Center(child: Text(emojiCtrl.text, style: const TextStyle(fontSize: 22)))),
                            const SizedBox(width: 12),
                            Expanded(
                              child: TextField(
                                controller: nameCtrl,
                                style: const TextStyle(fontSize: 13, color: AppColors.dark),
                                decoration: InputDecoration(
                                  filled: true, fillColor: AppColors.inputBg,
                                  hintText: 'Nom de la catégorie',
                                  hintStyle: const TextStyle(color: AppColors.placeholder, fontSize: 13),
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(AppRadius.lg), borderSide: BorderSide.none),
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () => setState(() => showAdd = false),
                              child: Container(padding: const EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                  child: const Text('Annuler', textAlign: TextAlign.center, style: TextStyle(color: AppColors.mutedFg, fontWeight: FontWeight.w600))),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: GestureDetector(
                              onTap: () {
                                if (nameCtrl.text.isNotEmpty) {
                                  setState(() {
                                    cats.add({'id': cats.length + 1, 'name': nameCtrl.text, 'emoji': emojiCtrl.text, 'count': 0, 'active': true});
                                    nameCtrl.clear();
                                    showAdd = false;
                                  });
                                }
                              },
                              child: Container(padding: const EdgeInsets.symmetric(vertical: 12),
                                  decoration: BoxDecoration(gradient: AppColors.adminGradient, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                  child: const Text('Ajouter', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                            ),
                          ),
                        ]),
                      ],
                    ),
                  ),
                ...cats.map((c) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 8)]),
                  child: Row(
                    children: [
                      Container(width: 44, height: 44,
                          decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.lg)),
                          child: Center(child: Text(c['emoji'], style: const TextStyle(fontSize: 22)))),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(c['name'], style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.dark)),
                            Text('${c['count']} offres', style: const TextStyle(fontSize: 11, color: AppColors.mutedFg)),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => setState(() => c['active'] = !(c['active'] as bool)),
                        child: Icon(
                          c['active'] ? Icons.toggle_on_rounded : Icons.toggle_off_rounded,
                          size: 36,
                          color: c['active'] ? AppColors.secondary : AppColors.placeholder,
                        ),
                      ),
                      const SizedBox(width: 4),
                      GestureDetector(onTap: () {}, child: const Icon(Icons.edit_rounded, size: 16, color: AppColors.mutedFg)),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () => setState(() => cats.removeWhere((x) => x['id'] == c['id'])),
                        child: const Icon(Icons.delete_rounded, size: 16, color: AppColors.destructive),
                      ),
                    ],
                  ),
                )),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
