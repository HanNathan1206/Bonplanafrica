import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../theme/app_colors.dart';
import '../../models/app_state.dart';

// ─── PARTNER DASHBOARD ───────────────────────────────────────────────────────

class PartnerDashboardScreen extends StatelessWidget {
  const PartnerDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final kpis = [
      {'label': 'Vues totales', 'value': '1 482', 'icon': Icons.visibility_rounded, 'color': AppColors.primary, 'bg': const Color(0xFFFFF3E0), 'change': '+12%'},
      {'label': 'Clics', 'value': '318', 'icon': Icons.touch_app_rounded, 'color': AppColors.secondary, 'bg': const Color(0xFFE8F5E9), 'change': '+8%'},
      {'label': 'Réservations', 'value': '52', 'icon': Icons.calendar_today_rounded, 'color': const Color(0xFF8E44AD), 'bg': const Color(0xFFF3E5F5), 'change': '+23%'},
      {'label': 'Note moy.', 'value': '4.7', 'icon': Icons.star_rounded, 'color': AppColors.accent, 'bg': const Color(0xFFFFFDE7), 'change': '+0.2'},
    ];

    final recentReservations = [
      {'name': 'Amina Koné', 'offer': 'Menu Grillades', 'date': 'Aujourd\'hui 12h', 'status': 'confirmed'},
      {'name': 'Pierre Moussavou', 'offer': 'Menu Grillades', 'date': 'Demain 19h', 'status': 'pending'},
      {'name': 'Fatou Diallo', 'offer': 'Menu Grillades x2', 'date': '22 Juin 13h', 'status': 'confirmed'},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            decoration: const BoxDecoration(gradient: AppColors.secondaryGradient),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Tableau de bord', style: TextStyle(color: Colors.white70, fontSize: 12)),
                        const Text('Le Mandingue', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 22)),
                        Row(children: [
                          Container(width: 8, height: 8, margin: const EdgeInsets.only(right: 6),
                              decoration: const BoxDecoration(color: Color(0xFF86EFAC), shape: BoxShape.circle)),
                          const Text('3 offres actives', style: TextStyle(color: Colors.white70, fontSize: 12)),
                        ]),
                      ],
                    ),
                    Stack(children: [
                      Container(width: 40, height: 40,
                          decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(AppRadius.lg)),
                          child: const Icon(Icons.notifications_rounded, color: Colors.white, size: 18)),
                      Positioned(top: 6, right: 6, child: Container(width: 8, height: 8,
                          decoration: BoxDecoration(color: Colors.red, shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 1)))),
                    ]),
                  ],
                ),
                const SizedBox(height: 16),
                GridView.count(
                  crossAxisCount: 2, childAspectRatio: 2.2,
                  shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 12, mainAxisSpacing: 12,
                  children: kpis.map((k) => Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: Colors.white15, borderRadius: BorderRadius.circular(AppRadius.xl)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(width: 28, height: 28,
                                decoration: BoxDecoration(color: Colors.white20, borderRadius: BorderRadius.circular(AppRadius.md)),
                                child: Icon(k['icon'] as IconData, size: 14, color: Colors.white)),
                            Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(color: Colors.white20, borderRadius: BorderRadius.circular(99)),
                                child: Text(k['change'] as String, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600))),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(k['value'] as String, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                            Text(k['label'] as String, style: const TextStyle(color: Colors.white70, fontSize: 10)),
                          ],
                        ),
                      ],
                    ),
                  )).toList(),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
              children: [
                // Quick actions
                const Text('Actions rapides', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.dark)),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: _actionBtn(context, Icons.add_circle_rounded, 'Créer une offre', AppColors.primary, () {
                      context.read<AppState>().setScreen(AppScreen.partnerCreate);
                    })),
                    const SizedBox(width: 12),
                    Expanded(child: _actionBtn(context, Icons.calendar_month_rounded, 'Réservations', AppColors.secondary, () {
                      context.read<AppState>().setPartnerTab(PartnerTab.reservations);
                    })),
                  ],
                ),
                const SizedBox(height: 20),
                // Recent reservations
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Dernières réservations', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.dark)),
                    const Text('Voir tout', style: TextStyle(color: AppColors.secondary, fontWeight: FontWeight.w600, fontSize: 12)),
                  ],
                ),
                const SizedBox(height: 10),
                ...recentReservations.map((r) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 8)]),
                  child: Row(
                    children: [
                      Container(width: 40, height: 40,
                          decoration: BoxDecoration(gradient: AppColors.secondaryGradient, shape: BoxShape.circle),
                          child: Center(child: Text(r['name']!.split(' ').map((e) => e[0]).take(2).join(),
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)))),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(r['name']!, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: AppColors.dark)),
                            Text('${r['offer']} — ${r['date']}', style: const TextStyle(fontSize: 11, color: AppColors.mutedFg)),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: r['status'] == 'confirmed' ? const Color(0xFFE8F5E9) : const Color(0xFFFFF3E0),
                          borderRadius: BorderRadius.circular(99),
                        ),
                        child: Text(
                          r['status'] == 'confirmed' ? '✅ Confirmé' : '⏳ Attente',
                          style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                              color: r['status'] == 'confirmed' ? AppColors.secondary : AppColors.primary),
                        ),
                      ),
                    ],
                  ),
                )),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _actionBtn(BuildContext context, IconData icon, String label, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(AppRadius.xl),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 26),
            const SizedBox(height: 6),
            Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 12), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

// ─── PARTNER OFFERS ──────────────────────────────────────────────────────────

class PartnerOffersScreen extends StatelessWidget {
  const PartnerOffersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final offers = [
      {'title': 'Menu Grillades + Boisson', 'price': '7 500 F', 'original': '12 000 F', 'views': 482, 'bookings': 23, 'status': 'active', 'expires': '2j'},
      {'title': 'Plateau de fruits de mer', 'price': '15 000 F', 'original': '22 000 F', 'views': 231, 'bookings': 11, 'status': 'active', 'expires': '5j'},
      {'title': 'Déjeuner d\'affaires', 'price': '9 000 F', 'original': '14 000 F', 'views': 89, 'bookings': 4, 'status': 'pending', 'expires': '-'},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Mes offres', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.dark)),
                GestureDetector(
                  onTap: () => context.read<AppState>().setScreen(AppScreen.partnerCreate),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(gradient: AppColors.secondaryGradient, borderRadius: BorderRadius.circular(AppRadius.lg)),
                    child: const Row(children: [
                      Icon(Icons.add_rounded, color: Colors.white, size: 16),
                      SizedBox(width: 4),
                      Text('Nouvelle', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
                    ]),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
              itemCount: offers.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final o = offers[i];
                final isActive = o['status'] == 'active';
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 10)]),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(child: Text(o['title'] as String,
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.dark))),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: isActive ? const Color(0xFFE8F5E9) : const Color(0xFFFFF3E0),
                              borderRadius: BorderRadius.circular(99),
                            ),
                            child: Text(isActive ? '● Actif' : '⏳ En attente',
                                style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                                    color: isActive ? AppColors.secondary : AppColors.primary)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Text(o['price'] as String, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: AppColors.primary)),
                          const SizedBox(width: 8),
                          Text(o['original'] as String, style: const TextStyle(fontSize: 12, color: AppColors.placeholder, decoration: TextDecoration.lineThrough)),
                          const Spacer(),
                          if (o['expires'] != '-') ...[
                            const Icon(Icons.access_time_rounded, size: 12, color: AppColors.primary),
                            const SizedBox(width: 4),
                            Text('${o['expires']} restant', style: const TextStyle(fontSize: 11, color: AppColors.primary, fontWeight: FontWeight.w600)),
                          ],
                        ],
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _statChip(Icons.visibility_rounded, '${o['views']} vues', AppColors.mutedFg),
                          const SizedBox(width: 10),
                          _statChip(Icons.calendar_today_rounded, '${o['bookings']} résas', AppColors.secondary),
                          const Spacer(),
                          GestureDetector(
                            onTap: () {},
                            child: const Icon(Icons.edit_rounded, size: 18, color: AppColors.primary),
                          ),
                          const SizedBox(width: 12),
                          GestureDetector(
                            onTap: () {},
                            child: const Icon(Icons.delete_rounded, size: 18, color: AppColors.destructive),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _statChip(IconData icon, String label, Color color) => Row(children: [
    Icon(icon, size: 12, color: color),
    const SizedBox(width: 4),
    Text(label, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w600)),
  ]);
}

// ─── CREATE OFFER ────────────────────────────────────────────────────────────

class CreateOfferScreen extends StatefulWidget {
  const CreateOfferScreen({super.key});
  @override
  State<CreateOfferScreen> createState() => _CreateOfferScreenState();
}

class _CreateOfferScreenState extends State<CreateOfferScreen> {
  final titleCtrl = TextEditingController();
  final descCtrl = TextEditingController();
  final origPriceCtrl = TextEditingController();
  final discPriceCtrl = TextEditingController();
  String selectedCat = 'restaurant';
  int duration = 7;

  final cats = [
    {'id': 'restaurant', 'label': '🍽️ Restaurant'},
    {'id': 'hotel', 'label': '🏨 Hôtel'},
    {'id': 'beaute', 'label': '💅 Beauté'},
    {'id': 'services', 'label': '🔧 Services'},
    {'id': 'loisirs', 'label': '🎯 Loisirs'},
  ];

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            decoration: const BoxDecoration(gradient: AppColors.secondaryGradient),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                GestureDetector(
                  onTap: () => state.setScreen(AppScreen.partnerOffers),
                  child: const Row(children: [
                    Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 18),
                    Text('Retour', style: TextStyle(color: Colors.white, fontSize: 13)),
                  ]),
                ),
                const SizedBox(height: 16),
                const Text('Créer une offre', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 22)),
                const Text('Publiez votre bon plan', style: TextStyle(color: Colors.white70, fontSize: 13)),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _field('Titre de l\'offre', titleCtrl, 'Ex: Menu déjeuner complet'),
                const SizedBox(height: 14),
                const Text('Catégorie', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.dark)),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8, runSpacing: 8,
                  children: cats.map((c) {
                    final isActive = selectedCat == c['id'];
                    return GestureDetector(
                      onTap: () => setState(() => selectedCat = c['id']!),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: isActive ? AppColors.secondary : AppColors.inputBg,
                          borderRadius: BorderRadius.circular(AppRadius.lg),
                        ),
                        child: Text(c['label']!, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                            color: isActive ? Colors.white : AppColors.mutedFg)),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 14),
                _field('Description', descCtrl, 'Décrivez votre offre en détail...', maxLines: 4),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(child: _field('Prix original (F)', origPriceCtrl, '12 000', type: TextInputType.number)),
                    const SizedBox(width: 12),
                    Expanded(child: _field('Prix promo (F)', discPriceCtrl, '7 500', type: TextInputType.number)),
                  ],
                ),
                const SizedBox(height: 14),
                const Text('Durée de l\'offre', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.dark)),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('$duration jours', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: AppColors.dark)),
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () { if (duration > 1) setState(() => duration--); },
                            child: Container(width: 32, height: 32,
                                decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                child: const Icon(Icons.remove_rounded, size: 16, color: AppColors.dark)),
                          ),
                          Padding(padding: const EdgeInsets.symmetric(horizontal: 16),
                              child: Text('$duration', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: AppColors.dark))),
                          GestureDetector(
                            onTap: () => setState(() => duration++),
                            child: Container(width: 32, height: 32,
                                decoration: BoxDecoration(color: AppColors.secondary, borderRadius: BorderRadius.circular(AppRadius.lg)),
                                child: const Icon(Icons.add_rounded, size: 16, color: Colors.white)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Photo upload placeholder
                const SizedBox(height: 14),
                GestureDetector(
                  onTap: () {},
                  child: Container(
                    height: 100,
                    decoration: BoxDecoration(
                      color: AppColors.inputBg,
                      borderRadius: BorderRadius.circular(AppRadius.xl),
                      border: Border.all(color: AppColors.border, style: BorderStyle.solid),
                    ),
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.add_photo_alternate_rounded, size: 30, color: AppColors.mutedFg),
                        SizedBox(height: 6),
                        Text('Ajouter des photos', style: TextStyle(color: AppColors.mutedFg, fontSize: 13, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                GestureDetector(
                  onTap: () => state.setPartnerTab(PartnerTab.dashboard),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    decoration: BoxDecoration(gradient: AppColors.secondaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl)),
                    child: const Text('Soumettre l\'offre', textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
                  ),
                ),
                const SizedBox(height: 8),
                const Text('Votre offre sera examinée par notre équipe avant publication (24h max).',
                    textAlign: TextAlign.center, style: TextStyle(color: AppColors.mutedFg, fontSize: 11)),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl, String hint, {int maxLines = 1, TextInputType type = TextInputType.text}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: AppColors.dark)),
        const SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(color: AppColors.inputBg, borderRadius: BorderRadius.circular(AppRadius.xl)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: TextField(
            controller: ctrl,
            maxLines: maxLines,
            keyboardType: type,
            style: const TextStyle(fontSize: 13, color: AppColors.dark),
            decoration: InputDecoration(border: InputBorder.none, hintText: hint,
                hintStyle: const TextStyle(color: AppColors.placeholder, fontSize: 13)),
          ),
        ),
      ],
    );
  }
}

// ─── PARTNER RESERVATIONS ────────────────────────────────────────────────────

class PartnerReservationsScreen extends StatelessWidget {
  const PartnerReservationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final reservations = [
      {'name': 'Amina Koné', 'offer': 'Menu Grillades + Boisson', 'date': 'Aujourd\'hui 12h00', 'persons': 2, 'status': 'confirmed', 'total': '15 000 F'},
      {'name': 'Pierre Moussavou', 'offer': 'Menu Grillades + Boisson', 'date': 'Demain 19h00', 'persons': 3, 'status': 'pending', 'total': '22 500 F'},
      {'name': 'Fatou Diallo', 'offer': 'Menu Grillades + Boisson', 'date': '22 Juin 13h00', 'persons': 2, 'status': 'confirmed', 'total': '15 000 F'},
      {'name': 'Jean-Paul Nkoghe', 'offer': 'Plateau de fruits de mer', 'date': '23 Juin 20h00', 'persons': 4, 'status': 'pending', 'total': '60 000 F'},
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            color: Colors.white,
            child: const Text('Réservations', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 22, color: AppColors.dark)),
          ),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 90),
              itemCount: reservations.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (context, i) {
                final r = reservations[i];
                final isPending = r['status'] == 'pending';
                return Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 8)]),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(r['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.dark)),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: isPending ? const Color(0xFFFFF3E0) : const Color(0xFFE8F5E9),
                              borderRadius: BorderRadius.circular(99),
                            ),
                            child: Text(isPending ? '⏳ En attente' : '✅ Confirmé',
                                style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700,
                                    color: isPending ? AppColors.primary : AppColors.secondary)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(r['offer'] as String, style: const TextStyle(fontSize: 13, color: AppColors.mutedFg)),
                      const SizedBox(height: 6),
                      Row(children: [
                        const Icon(Icons.access_time_rounded, size: 12, color: AppColors.mutedFg),
                        const SizedBox(width: 4),
                        Text(r['date'] as String, style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
                        const SizedBox(width: 12),
                        const Icon(Icons.group_rounded, size: 12, color: AppColors.mutedFg),
                        const SizedBox(width: 4),
                        Text('${r['persons']} pers.', style: const TextStyle(fontSize: 12, color: AppColors.mutedFg)),
                        const Spacer(),
                        Text(r['total'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: AppColors.primary)),
                      ]),
                      if (isPending) ...[
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: GestureDetector(
                                onTap: () {},
                                child: Container(
                                  padding: const EdgeInsets.symmetric(vertical: 10),
                                  decoration: BoxDecoration(color: const Color(0xFFE8F5E9), borderRadius: BorderRadius.circular(AppRadius.lg)),
                                  child: const Text('Confirmer', textAlign: TextAlign.center,
                                      style: TextStyle(color: AppColors.secondary, fontWeight: FontWeight.w700, fontSize: 12)),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: GestureDetector(
                                onTap: () {},
                                child: Container(
                                  padding: const EdgeInsets.symmetric(vertical: 10),
                                  decoration: BoxDecoration(color: const Color(0xFFFFF0F0), borderRadius: BorderRadius.circular(AppRadius.lg)),
                                  child: const Text('Refuser', textAlign: TextAlign.center,
                                      style: TextStyle(color: AppColors.destructive, fontWeight: FontWeight.w700, fontSize: 12)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── PARTNER PROFILE ─────────────────────────────────────────────────────────

class PartnerProfileScreen extends StatelessWidget {
  const PartnerProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 30),
            decoration: const BoxDecoration(gradient: AppColors.secondaryGradient),
            child: Column(
              children: [
                Container(
                  width: 80, height: 80,
                  decoration: const BoxDecoration(color: Colors.white24, shape: BoxShape.circle),
                  child: const Center(child: Text('LM', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 26))),
                ),
                const SizedBox(height: 12),
                const Text('Le Mandingue', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 20)),
                const Text('Restaurant africain — Libreville, Louis', style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _pill('3', 'Offres actives'),
                    const SizedBox(width: 12),
                    _pill('4.8⭐', 'Note'),
                    const SizedBox(width: 12),
                    _pill('52', 'Réservations'),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 12),
              children: [
                _section('Commerce', [
                  _item(Icons.store_rounded, 'Informations du commerce'),
                  _item(Icons.photo_camera_rounded, 'Photos & médias'),
                  _item(Icons.access_time_rounded, 'Horaires d\'ouverture'),
                  _item(Icons.payment_rounded, 'Modes de paiement'),
                ]),
                const SizedBox(height: 8),
                _section('Abonnement', [
                  _premiumBanner(),
                ]),
                const SizedBox(height: 8),
                _section('Paramètres', [
                  _item(Icons.notifications_rounded, 'Notifications'),
                  _item(Icons.help_rounded, 'Aide & Support'),
                ]),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: GestureDetector(
                    onTap: () => state.logout(),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(color: const Color(0xFFFFF0F0), borderRadius: BorderRadius.circular(AppRadius.xl)),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.logout_rounded, color: AppColors.destructive, size: 18),
                          SizedBox(width: 8),
                          Text('Se déconnecter', style: TextStyle(color: AppColors.destructive, fontWeight: FontWeight.w700, fontSize: 15)),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 90),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static Widget _pill(String value, String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(AppRadius.lg)),
    child: Column(children: [
      Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16)),
      Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10)),
    ]),
  );

  static Widget _premiumBanner() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(gradient: AppColors.primaryGradient, borderRadius: BorderRadius.circular(AppRadius.xl)),
    child: const Row(
      children: [
        Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 26),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Abonnement Gratuit', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
              Text('Passez à Premium pour + de visibilité et d\'analyses', style: TextStyle(color: Colors.white70, fontSize: 11)),
            ],
          ),
        ),
        Icon(Icons.chevron_right_rounded, color: Colors.white70),
      ],
    ),
  );

  static Widget _section(String title, List<Widget> items) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(padding: const EdgeInsets.only(bottom: 8, top: 4),
            child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, color: AppColors.mutedFg))),
        Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(AppRadius.xl),
              boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 8)]),
          child: Column(children: items),
        ),
      ],
    ),
  );

  static Widget _item(IconData icon, String label) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    child: Row(children: [
      Container(width: 36, height: 36,
          decoration: BoxDecoration(color: AppColors.muted, borderRadius: BorderRadius.circular(AppRadius.md)),
          child: Icon(icon, size: 18, color: AppColors.mutedFg)),
      const SizedBox(width: 12),
      Expanded(child: Text(label, style: const TextStyle(fontSize: 14, color: AppColors.dark, fontWeight: FontWeight.w500))),
      const Icon(Icons.chevron_right_rounded, size: 18, color: AppColors.placeholder),
    ]),
  );
}
